import React, { useState } from 'react';
import './App.css';

function App() {
  const [balance, setBalance] = useState(100);
  const symbols = ["🍒", "🍋", "🔔", "7️⃣", "💎"];
  const [slot, setSlot] = useState(["?", "?", "?"]);

  const spin = () => {
    const result = [
      symbols[Math.floor(Math.random() * symbols.length)],
      symbols[Math.floor(Math.random() * symbols.length)],
      symbols[Math.floor(Math.random() * symbols.length)]
    ];
    setSlot(result);
    if (result[0] === result[1] && result[1] === result[2]) {
      setBalance(balance + 50);
    } else {
      setBalance(balance - 10);
    }
  };

  return (
    <div className="App">
      <h1>Bakanabet</h1>
      <p>Saldo: R$ {balance}</p>
      <div style={{ fontSize: '2rem' }}>{slot.join(' ')}</div>
      <button onClick={spin}>Girar Slot (-R$10)</button>
    </div>
  );
}

export default App;